#!/bin/sh
cd /home/site/wwwroot
npm start
